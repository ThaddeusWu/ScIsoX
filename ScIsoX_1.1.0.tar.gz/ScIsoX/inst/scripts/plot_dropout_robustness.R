#!/usr/bin/env Rscript
##################################################################
#  Visualize Dropout Robustness Analysis Results                 #
##################################################################

library(ggplot2)
library(dplyr)
library(tidyr)
library(patchwork)

#' Create dropout robustness visualization
#' 
#' @param summary_file Path to dropout_comparison_summary.csv
#' @param output_dir Directory to save plots
#' @return List of ggplot objects
plot_dropout_robustness <- function(summary_file = "results/dropout_robustness/dropout_comparison_summary.csv",
                                  output_dir = "results/dropout_robustness/plots") {
  
  # Create output directory
  if (!dir.exists(output_dir)) {
    dir.create(output_dir, recursive = TRUE)
  }
  
  # Read summary data
  summary_data <- read.csv(summary_file)
  
  # Manually input the per-metric data based on your results
  # (In practice, this would be read from saved detailed results)
  metric_data <- data.frame(
    dropout_level = rep(c(0.1, 0.2, 0.3, 0.4, 0.5), each = 7),
    metric = rep(c(
      "intra_cellular_isoform_diversity",
      "inter_cellular_isoform_diversity",
      "intra_cell_type_heterogeneity",
      "inter_cell_type_specificity",
      "intra_cell_type_heterogeneity_variability",
      "inter_cell_type_difference_variability",
      "cell_type_coexpression_variability"
    ), 5),
    overlap = c(
      # 10% dropout
      0.908, 0.964, 0.962, 0.969, 0.942, 0.963, 0.930,
      # 20% dropout
      0.897, 0.950, 0.958, 0.950, 0.920, 0.950, 0.903,
      # 30% dropout
      0.863, 0.915, 0.946, 0.907, 0.899, 0.921, 0.880,
      # 40% dropout
      0.812, 0.876, 0.935, 0.856, 0.866, 0.895, 0.818,
      # 50% dropout
      0.733, 0.770, 0.887, 0.749, 0.808, 0.856, 0.737
    ),
    cliffs_delta = c(
      # 10% dropout
      0.004, 0.025, 0.016, 0.031, 0.012, 0.004, 0.018,
      # 20% dropout
      0.021, 0.045, 0.013, 0.059, 0.033, 0.017, 0.046,
      # 30% dropout
      0.028, 0.103, 0.005, 0.130, 0.033, 0.018, 0.059,
      # 40% dropout
      0.039, 0.160, 0.026, 0.202, 0.048, 0.025, 0.088,
      # 50% dropout
      0.082, 0.300, 0.125, 0.345, 0.123, 0.051, 0.118
    )
  )
  
  # Clean metric names for display
  metric_data$metric_display <- gsub("_", " ", metric_data$metric)
  metric_data$metric_display <- tools::toTitleCase(metric_data$metric_display)
  
  # 1. Overall trend plot
  overall_summary <- metric_data %>%
    group_by(dropout_level) %>%
    summarise(
      mean_overlap = mean(overlap),
      sd_overlap = sd(overlap),
      mean_cliffs = mean(cliffs_delta),
      sd_cliffs = sd(cliffs_delta)
    )
  
  p1 <- ggplot(overall_summary, aes(x = dropout_level * 100, y = mean_overlap)) +
    geom_ribbon(aes(ymin = mean_overlap - sd_overlap, 
                    ymax = mean_overlap + sd_overlap),
                alpha = 0.2, fill = "blue") +
    geom_line(color = "darkblue", size = 1.5) +
    geom_point(color = "darkblue", size = 4) +
    geom_hline(yintercept = 0.8, linetype = "dashed", color = "red", size = 1.5) +
    scale_y_continuous(limits = c(0.5, 1), breaks = seq(0.5, 1, 0.1)) +
    scale_x_continuous(breaks = c(10, 20, 30, 40, 50)) +
    labs(
      title = "Overall Metric Robustness to Dropout",
      subtitle = "Mean overlap coefficient across all 7 complexity metrics",
      x = "Additional Dropout Rate (%)",
      y = "Mean Overlap Coefficient",
      caption = "Shaded area: ±1 SD; Red line: 0.8 threshold for high similarity.\nOverlap coefficient measures distribution similarity (1 = identical, 0 = no overlap)."
    ) +
    theme_minimal(base_size = 14) +
    theme(
      plot.title = element_text(face = "bold", size = 16),
      plot.subtitle = element_text(size = 12),
      axis.title = element_text(face = "bold"),
      panel.grid.minor = element_blank()
    )
  
  # 2. Per-metric heatmap
  p2 <- ggplot(metric_data, aes(x = dropout_level * 100, y = metric_display, fill = overlap)) +
    geom_tile() +
    geom_text(aes(label = sprintf("%.3f", overlap)), size = 3) +
    scale_fill_gradient2(
      low = "red", 
      mid = "yellow", 
      high = "darkgreen",
      midpoint = 0.8,
      limits = c(0.7, 1),
      name = "Overlap\nCoefficient"
    ) +
    scale_x_continuous(breaks = c(10, 20, 30, 40, 50)) +
    labs(
      title = "Per-Metric Robustness Heatmap",
      subtitle = "Overlap coefficient for each metric at different dropout levels",
      x = "Additional Dropout Rate (%)",
      y = ""
    ) +
    theme_minimal(base_size = 12) +
    theme(
      plot.title = element_text(face = "bold", size = 16),
      axis.text.y = element_text(size = 10),
      axis.title = element_text(face = "bold"),
      panel.grid = element_blank()
    )
  
  # 3. Individual metric trends
  p3 <- ggplot(metric_data, aes(x = dropout_level * 100, y = overlap, 
                                color = metric_display, group = metric_display)) +
    geom_line(size = 1.2) +
    geom_point(size = 2) +
    geom_hline(yintercept = 0.8, linetype = "dashed", color = "gray50", size = 1.2) +
    scale_y_continuous(limits = c(0.7, 1)) +
    scale_x_continuous(breaks = c(10, 20, 30, 40, 50)) +
    scale_color_manual(values = c(
      "Intra Cellular Isoform Diversity" = "#E41A1C",
      "Inter Cellular Isoform Diversity" = "#377EB8",
      "Intra Cell Type Heterogeneity" = "#4DAF4A",
      "Inter Cell Type Specificity" = "#984EA3",
      "Intra Cell Type Heterogeneity Variability" = "#FF7F00",
      "Inter Cell Type Difference Variability" = "#FFFF33",
      "Cell Type Coexpression Variability" = "#A65628"
    )) +
    labs(
      title = "Individual Metric Robustness Trends",
      x = "Additional Dropout Rate (%)",
      y = "Overlap Coefficient",
      color = "Metric"
    ) +
    theme_minimal(base_size = 12) +
    theme(
      plot.title = element_text(face = "bold", size = 16),
      axis.title = element_text(face = "bold"),
      legend.position = "bottom",
      legend.text = element_text(size = 9),
      legend.title = element_text(face = "bold"),
      panel.grid.minor = element_blank()
    ) +
    guides(color = guide_legend(ncol = 2))
  
  # 4. Cliff's Delta plot
  p4 <- ggplot(metric_data, aes(x = dropout_level * 100, y = cliffs_delta, 
                                color = metric_display, group = metric_display)) +
    geom_line(size = 1.2) +
    geom_point(size = 2) +
    geom_hline(yintercept = 0.147, linetype = "dashed", color = "red", size = 1.2) +
    geom_hline(yintercept = 0.33, linetype = "dashed", color = "orange", size = 1.2) +
    scale_y_continuous(limits = c(0, 0.4)) +
    scale_x_continuous(breaks = c(10, 20, 30, 40, 50)) +
    scale_color_manual(values = c(
      "Intra Cellular Isoform Diversity" = "#E41A1C",
      "Inter Cellular Isoform Diversity" = "#377EB8",
      "Intra Cell Type Heterogeneity" = "#4DAF4A",
      "Inter Cell Type Specificity" = "#984EA3",
      "Intra Cell Type Heterogeneity Variability" = "#FF7F00",
      "Inter Cell Type Difference Variability" = "#FFFF33",
      "Cell Type Coexpression Variability" = "#A65628"
    )) +
    labs(
      title = "Effect Size (Cliff's Delta) Trends",
      x = "Additional Dropout Rate (%)",
      y = "Cliff's Delta",
      color = "Metric",
      caption = "Cliff's Delta measures effect size: < 0.147 = negligible (below red line), 0.147-0.33 = small (red to orange),\n0.33-0.474 = medium (above orange), > 0.474 = large. Lower values indicate higher similarity."
    ) +
    theme_minimal(base_size = 12) +
    theme(
      plot.title = element_text(face = "bold", size = 16),
      axis.title = element_text(face = "bold"),
      legend.position = "none",
      panel.grid.minor = element_blank()
    )
  
  # Save plots
  ggsave(file.path(output_dir, "overall_robustness_trend.pdf"), 
         p1, width = 8, height = 6)
  
  ggsave(file.path(output_dir, "per_metric_heatmap.pdf"), 
         p2, width = 10, height = 8)
  
  ggsave(file.path(output_dir, "individual_metric_trends.pdf"), 
         p3, width = 10, height = 8)
  
  ggsave(file.path(output_dir, "cliffs_delta_trends.pdf"), 
         p4, width = 10, height = 6)
  
  # Combined plot for main figure
  combined <- (p1 | p2) / (p3 | p4) + 
    plot_annotation(
      title = "Dropout Robustness Analysis of Isoform Complexity Metrics",
      theme = theme(plot.title = element_text(size = 18, face = "bold"))
    )
  
  ggsave(file.path(output_dir, "dropout_robustness_combined.pdf"), 
         combined, width = 16, height = 12)
  
  cat(sprintf("\nPlots saved to: %s\n", output_dir))
  
  # Display combined plot in RStudio plot window
  print(combined)
  
  return(list(
    overall = p1,
    heatmap = p2,
    trends = p3,
    cliffs = p4,
    combined = combined
  ))
}

# Run if executed directly
if (!interactive()) {
  plots <- plot_dropout_robustness()
}