#!/usr/bin/env Rscript
##################################################################
#  Dropout Robustness Test - Clean Version for mouse_isoform_df  #
##################################################################

#' Add dropout to a matrix preserving gene-isoform relationships
#' 
#' @param transcript_counts Transcript count matrix
#' @param transcript_info Transcript information with gene mapping
#' @param dropout_rate Proportion of non-zero values to convert to zero
#' @param seed Random seed for reproducibility
#' @return List with dropout versions of all matrices
add_dropout_preserving_structure <- function(transcript_counts, 
                                           transcript_info, dropout_rate, seed = NULL) {
  if (!is.null(seed)) set.seed(seed)
  
  # Convert to sparse matrices if needed
  if (!inherits(transcript_counts, "sparseMatrix")) {
    transcript_counts <- as(as.matrix(transcript_counts), "sparseMatrix")
  }
  
  # Apply dropout to transcript matrix
  transcript_dropout <- transcript_counts
  
  # More efficient dropout implementation
  if (inherits(transcript_dropout, "sparseMatrix")) {
    # For sparse matrices, work directly with the non-zero values
    n_nonzero <- length(transcript_dropout@x)
    n_dropout <- round(n_nonzero * dropout_rate)
    
    if (n_dropout > 0 && n_dropout < n_nonzero) {
      # Randomly select which non-zero values to drop
      dropout_idx <- sample(1:n_nonzero, n_dropout, replace = FALSE)
      transcript_dropout@x[dropout_idx] <- 0
      # Clean up the sparse matrix
      transcript_dropout <- Matrix::drop0(transcript_dropout)
    }
  } else {
    # For dense matrices, use vectorized operations
    non_zero_mask <- transcript_dropout > 0
    n_nonzero <- sum(non_zero_mask)
    n_dropout <- round(n_nonzero * dropout_rate)
    
    if (n_dropout > 0 && n_dropout < n_nonzero) {
      # Get indices of non-zero elements
      non_zero_idx <- which(non_zero_mask)
      # Randomly select which ones to drop
      dropout_idx <- sample(non_zero_idx, n_dropout, replace = FALSE)
      transcript_dropout[dropout_idx] <- 0
    }
  }
  
  # Recalculate gene counts based on dropout transcripts
  # Convert back to regular matrix for generate_gene_counts
  transcript_dropout_dense <- as.matrix(transcript_dropout)
  
  # generate_gene_counts should already be loaded
  gene_result <- generate_gene_counts(transcript_dropout_dense, show_progress = FALSE)
  
  # Clean up sparse matrices
  transcript_dropout <- Matrix::drop0(transcript_dropout)
  # gene_counts might already be a regular matrix
  gene_counts_dropout <- gene_result$gene_counts
  
  return(list(
    transcript_counts = transcript_dropout,
    gene_counts = gene_counts_dropout,
    transcript_info = transcript_info
  ))
}

#' Run dropout robustness analysis
#' 
#' @param transcript_counts Original transcript count matrix
#' @param transcript_info Transcript information
#' @param metadata Cell metadata
#' @param dropout_levels Vector of dropout rates to test
#' @param n_iterations Number of iterations per dropout level
#' @param output_dir Directory to save results
#' @param qc_params QC parameters (optional, will use defaults if NULL)
#' @param n_hvg Number of highly variable genes
#' @return List containing all results
run_dropout_robustness <- function(transcript_counts, 
                                 transcript_info,
                                 metadata,
                                 dropout_levels = c(0.1, 0.2, 0.3, 0.4, 0.5),
                                 n_iterations = 20,
                                 output_dir = "results/dropout_robustness",
                                 qc_params = NULL,
                                 n_hvg = 3000) {
  
  cat("\n=== Dropout Robustness Analysis ===\n")
  cat(sprintf("Testing %d dropout levels with %d iterations each\n", 
              length(dropout_levels), n_iterations))
  
  # Create output directory
  if (!dir.exists(output_dir)) {
    dir.create(output_dir, recursive = TRUE)
  }
  
  # Generate gene counts
  cat("\nGenerating gene counts from transcript counts...\n")
  source("/Users/jc952373/Documents/BioMathStiX/My_Packages/ScIsoX/R/generate_gene_counts.R")
  gene_result <- generate_gene_counts(transcript_counts, show_progress = FALSE)
  gene_counts <- gene_result$gene_counts
  
  # Load required functions
  source("/Users/jc952373/Documents/BioMathStiX/My_Packages/ScIsoX/R/create_scht.R")
  source("/Users/jc952373/Documents/BioMathStiX/My_Packages/ScIsoX/R/complexity_metrics.R")
  
  # Use default QC parameters if not provided
  if (is.null(qc_params)) {
    qc_params <- list(
      min_genes_per_cell = 200,
      max_genes_per_cell = 10000,
      min_cells_expressing = 0.02,
      min_expr = 1e-6
    )
  }
  
  cat("Using QC parameters:\n")
  cat(sprintf("  min_genes_per_cell: %d\n", qc_params$min_genes_per_cell))
  cat(sprintf("  max_genes_per_cell: %d\n", qc_params$max_genes_per_cell))
  cat(sprintf("  min_cells_expressing: %.2f\n", qc_params$min_cells_expressing))
  cat(sprintf("  n_hvg: %d\n", n_hvg))
  
  # Calculate original metrics as baseline
  cat("\nCalculating baseline metrics...\n")
  scht_original <- create_scht(
    gene_counts = gene_counts,
    transcript_counts = transcript_counts,
    transcript_info = transcript_info,
    cell_info = metadata,
    qc_params = qc_params,
    n_hvg = n_hvg
  )
  
  # Check if SCHT has multi-isoform genes
  if (is.null(scht_original$original_results) || 
      length(scht_original$original_results) == 0) {
    stop("No genes with multiple isoforms found in SCHT structure.")
  }
  
  cat(sprintf("Found %d genes with multiple isoforms\n", 
              length(scht_original$original_results)))
  
  original_metrics <- calculate_isoform_complexity_metrics(
    scht_original,
    data_driven_thresholds = FALSE,
    visualise = FALSE
  )$metrics
  
  cat(sprintf("Baseline metrics calculated for %d genes\n", nrow(original_metrics)))
  
  # Initialize results storage
  all_results <- list()
  comparison_results <- list()
  
  # Test each dropout level
  for (level in dropout_levels) {
    cat(sprintf("\n--- Testing dropout level: %.0f%% ---\n", level * 100))
    
    level_results <- list()
    
    # Simple progress tracking without progress bar
    successful_iterations <- 0
    
    for (iter in 1:n_iterations) {
      cat(sprintf("  Iteration %d/%d: ", iter, n_iterations))
      
      # Apply dropout
      cat("applying dropout...")
      dropout_data <- add_dropout_preserving_structure(
        transcript_counts, transcript_info,
        dropout_rate = level, 
        seed = iter + level * 1000
      )
      cat("done. ")
      
      # Create SCHT with dropout data
      tryCatch({
        cat("creating SCHT...")
        scht_dropout <- create_scht(
          gene_counts = dropout_data$gene_counts,
          transcript_counts = dropout_data$transcript_counts,
          transcript_info = dropout_data$transcript_info,
          cell_info = metadata,
          qc_params = qc_params,
          n_hvg = n_hvg,
          verbose = FALSE  # Turn off verbose for cleaner output
        )
        cat("done. ")
        
        # Calculate metrics
        cat("calculating metrics...")
        metrics_dropout <- calculate_isoform_complexity_metrics(
          scht_dropout,
          data_driven_thresholds = FALSE,
          visualise = FALSE,
          verbose = FALSE  # Turn off verbose for cleaner output
        )$metrics
        cat("done.\n")
        
        if (nrow(metrics_dropout) > 0) {
          level_results[[iter]] <- metrics_dropout
          successful_iterations <- successful_iterations + 1
        }
        
      }, error = function(e) {
        # Report error instead of silently skipping
        cat("ERROR: ", e$message, "\n")
      })
    }
    
    cat(sprintf("  Successful iterations: %d/%d\n", successful_iterations, n_iterations))
    
    # Store all iterations for this level
    all_results[[as.character(level)]] <- level_results
    
    if (length(level_results) > 0) {
      # Compare each iteration with original
      level_comparisons <- list()
      
      for (i in 1:length(level_results)) {
        # Load comparison function
        source("/Users/jc952373/Documents/BioMathStiX/My_Packages/ScIsoX/inst/scripts/compare_metrics_distributions.R")
        
        # Compare this iteration with original
        comparison <- compare_metrics_distributions(
          list(metrics = original_metrics),
          list(metrics = level_results[[i]]),
          plot = FALSE,
          save_results = FALSE,
          label1 = "Original",
          label2 = sprintf("Dropout %.0f%% Iter %d", level * 100, i)
        )
        
        level_comparisons[[i]] <- comparison
      }
      
      # Store comparison results
      comparison_results[[as.character(level)]] <- level_comparisons
      
      # Calculate summary statistics across iterations for each metric
      cat("\n  Per-metric summary across iterations:\n")
      cat("  Metric                                       | Mean Overlap (SD) [CV] | Mean Cliff's (SD) [CV]\n")
      cat("  ------------------------------------------------------------------------------------------\n")
      
      # Extract per-metric values from comparison results
      metric_stats <- list()
      for (comp in level_comparisons) {
        for (i in 1:length(comp$summary$metric)) {
          metric <- comp$summary$metric[i]
          if (!(metric %in% names(metric_stats))) {
            metric_stats[[metric]] <- list(overlap = c(), cliffs = c())
          }
          metric_stats[[metric]]$overlap <- c(metric_stats[[metric]]$overlap, comp$summary$overlap[i])
          metric_stats[[metric]]$cliffs <- c(metric_stats[[metric]]$cliffs, comp$summary$cliffs_delta[i])
        }
      }
      
      # Calculate and display per-metric statistics
      for (metric in names(metric_stats)) {
        overlap_mean <- mean(metric_stats[[metric]]$overlap)
        overlap_sd <- sd(metric_stats[[metric]]$overlap)
        overlap_cv <- overlap_sd / overlap_mean
        
        cliffs_mean <- mean(metric_stats[[metric]]$cliffs)
        cliffs_sd <- sd(metric_stats[[metric]]$cliffs)
        cliffs_cv <- ifelse(cliffs_mean != 0, abs(cliffs_sd / cliffs_mean), 0)
        
        metric_display <- gsub("_", " ", metric)
        cat(sprintf("  %-45s | %.3f (%.3f) [%.2f] | %.3f (%.3f) [%.2f]\n",
                    metric_display,
                    overlap_mean, overlap_sd, overlap_cv,
                    cliffs_mean, cliffs_sd, cliffs_cv))
      }
      
      # Save metrics for this dropout level as CSV
      for (i in 1:length(level_results)) {
        write.csv(level_results[[i]], 
                  file.path(output_dir, sprintf("dropout_metrics_%d_percent_iter_%d.csv", level * 100, i)),
                  row.names = FALSE)
      }
      cat(sprintf("\n  Saved %d iteration files to %s\n", 
                  length(level_results), output_dir))
    }
  }
  
  # Save the original metrics as CSV
  write.csv(original_metrics, 
            file.path(output_dir, "original_metrics.csv"),
            row.names = FALSE)
  cat(sprintf("\nOriginal metrics saved to: %s\n", 
              file.path(output_dir, "original_metrics.csv")))
  
  # Print final summary with comparison statistics
  cat("\n=== Summary ===\n")
  cat("Dropout Level | Iterations | Mean Overlap (SD) | Mean |Cliff's Delta| (SD)\n")
  cat("----------------------------------------------------------------------------\n")
  
  summary_data <- data.frame()
  
  for (level in dropout_levels) {
    level_results <- all_results[[as.character(level)]]
    level_comparisons <- comparison_results[[as.character(level)]]
    
    if (length(level_results) > 0 && length(level_comparisons) > 0) {
      all_overlaps <- sapply(level_comparisons, function(x) x$overlap)
      all_cliffs_delta <- sapply(level_comparisons, function(x) x$cliffs_delta)
      
      cat(sprintf("    %3.0f%%     |     %2d     |   %.3f (%.3f)    |      %.3f (%.3f)\n",
                  level * 100,
                  length(level_results),
                  mean(all_overlaps),
                  sd(all_overlaps),
                  mean(abs(all_cliffs_delta)),
                  sd(abs(all_cliffs_delta))))
      
      # Store summary for potential plotting
      summary_data <- rbind(summary_data, data.frame(
        dropout_level = level,
        n_iterations = length(level_results),
        mean_overlap = mean(all_overlaps),
        sd_overlap = sd(all_overlaps),
        mean_cliffs_delta = mean(abs(all_cliffs_delta)),
        sd_cliffs_delta = sd(abs(all_cliffs_delta))
      ))
    } else {
      cat(sprintf("    %3.0f%%     |     %2d     |       N/A        |         N/A\n",
                  level * 100, 0))
    }
  }
  
  # Save summary statistics
  if (nrow(summary_data) > 0) {
    write.csv(summary_data, 
              file.path(output_dir, "dropout_comparison_summary.csv"),
              row.names = FALSE)
  }
  
  # Return all results
  return(list(
    original_metrics = original_metrics,
    dropout_results = all_results,
    comparison_results = comparison_results,
    summary = summary_data,
    qc_params = qc_params,
    output_dir = output_dir
  ))
}

# Example usage
if (interactive()) {
  cat("\nExample usage:\n")
  cat("==============\n")
  cat("# Load mouse_isoform_df data\n")
  cat("transcript_counts <- readRDS('mouse_isoform_df.rds')\n")
  cat("metadata <- readRDS('metadata.rds')\n\n")
  cat("# Generate transcript info\n")
  cat("gene_result <- generate_gene_counts(transcript_counts)\n")
  cat("transcript_info <- gene_result$transcript_info\n\n")
  cat("# Run dropout analysis\n")
  cat("results <- run_dropout_robustness(\n")
  cat("  transcript_counts, transcript_info, metadata,\n")
  cat("  dropout_levels = c(0.1, 0.2, 0.3, 0.4, 0.5),\n")
  cat("  n_iterations = 20\n")
  cat(")\n\n")
  cat("# Dropout metrics will be saved as CSV files in the output directory\n")
  cat("# To load and compare later:\n")
  cat("original <- read.csv(file.path(results$output_dir, 'original_metrics.csv'))\n")
  cat("dropout_10_iter1 <- read.csv(file.path(results$output_dir, 'dropout_metrics_10_percent_iter_1.csv'))\n")
}