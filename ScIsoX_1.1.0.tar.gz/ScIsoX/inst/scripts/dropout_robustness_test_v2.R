#!/usr/bin/env Rscript
##################################################################
#  Dropout Robustness Test V2 - Using Existing Data Structure   #
##################################################################

#' Add dropout to a matrix preserving gene-isoform relationships
#' 
#' @param transcript_counts Transcript count matrix
#' @param transcript_info Transcript information with gene mapping
#' @param dropout_rate Proportion of non-zero values to convert to zero
#' @param seed Random seed for reproducibility
#' @return List with dropout versions of all matrices
add_dropout_preserving_structure <- function(transcript_counts, 
                                           transcript_info, dropout_rate, seed = NULL) {
  if (!is.null(seed)) set.seed(seed)
  
  # Convert to sparse matrices if needed
  if (!inherits(transcript_counts, "sparseMatrix")) {
    transcript_counts <- as(as.matrix(transcript_counts), "sparseMatrix")
  }
  
  # Apply dropout to transcript matrix
  transcript_dropout <- transcript_counts
  non_zero_idx <- which(transcript_dropout > 0, arr.ind = TRUE)
  n_dropout <- round(nrow(non_zero_idx) * dropout_rate)
  
  if (n_dropout > 0) {
    dropout_idx <- sample(1:nrow(non_zero_idx), n_dropout, replace = FALSE)
    for (i in dropout_idx) {
      transcript_dropout[non_zero_idx[i, 1], non_zero_idx[i, 2]] <- 0
    }
  }
  
  # Recalculate gene counts based on dropout transcripts
  # First get unique genes from transcript_info
  unique_genes <- unique(transcript_info$gene_name)
  gene_counts_new <- matrix(0, nrow = length(unique_genes), ncol = ncol(transcript_dropout))
  rownames(gene_counts_new) <- unique_genes
  colnames(gene_counts_new) <- colnames(transcript_dropout)
  
  for (gene in unique_genes) {
    # Find transcripts for this gene
    gene_transcripts <- transcript_info$transcript_name[transcript_info$gene_name == gene]
    gene_transcripts <- intersect(gene_transcripts, rownames(transcript_dropout))
    
    if (length(gene_transcripts) > 0) {
      # Sum transcript counts for this gene
      if (length(gene_transcripts) == 1) {
        gene_counts_new[gene, ] <- transcript_dropout[gene_transcripts, ]
      } else {
        gene_counts_new[gene, ] <- Matrix::colSums(transcript_dropout[gene_transcripts, , drop = FALSE])
      }
    }
  }
  
  # Convert back to sparse
  gene_counts_dropout <- as(gene_counts_new, "sparseMatrix")
  transcript_dropout <- Matrix::drop0(transcript_dropout)
  gene_counts_dropout <- Matrix::drop0(gene_counts_dropout)
  
  return(list(
    transcript_counts = transcript_dropout,
    gene_counts = gene_counts_dropout,
    transcript_info = transcript_info
  ))
}

#' Run dropout robustness analysis with existing data structure
#' 
#' @param transcript_counts Original transcript count matrix
#' @param gene_counts Original gene count matrix
#' @param transcript_info Transcript information
#' @param metadata Cell metadata
#' @param dropout_levels Vector of dropout rates to test
#' @param n_iterations Number of iterations per dropout level
#' @param output_dir Directory to save results
#' @param save_plots Whether to save plots
#' @return List containing all results
run_dropout_robustness_v2 <- function(transcript_counts, 
                                    transcript_info,
                                    metadata,
                                    dropout_levels = c(0.1, 0.2, 0.3, 0.4, 0.5),
                                    n_iterations = 20,
                                    output_dir = "results/dropout_robustness",
                                    save_plots = TRUE) {
  
  cat("\n=== Dropout Robustness Analysis V2 ===\n")
  cat("Using provided gene-transcript mapping\n")
  cat(sprintf("Testing %d dropout levels with %d iterations each\n", 
              length(dropout_levels), n_iterations))
  
  # Create output directory
  if (save_plots && !dir.exists(output_dir)) {
    dir.create(output_dir, recursive = TRUE)
  }
  
  # Calculate gene counts from transcript counts
  cat("\nCalculating gene counts from transcript counts...\n")
  source("/Users/jc952373/Documents/BioMathStiX/My_Packages/ScIsoX/R/generate_gene_counts.R")
  
  # First, filter transcript_counts to only include transcripts in transcript_info
  common_transcripts <- intersect(rownames(transcript_counts), transcript_info$transcript_id)
  cat(sprintf("Found %d transcripts in both matrix and info (out of %d in matrix)\n", 
              length(common_transcripts), nrow(transcript_counts)))
  
  # Filter the transcript counts
  transcript_counts_filtered <- transcript_counts[common_transcripts, ]
  
  # Create mapping from transcript_id to transcript_name
  id_to_name <- setNames(transcript_info$transcript_name, transcript_info$transcript_id)
  
  # Rename rows to use transcript names instead of IDs
  transcript_counts_renamed <- transcript_counts_filtered
  rownames(transcript_counts_renamed) <- id_to_name[rownames(transcript_counts_filtered)]
  
  # Now we can use generate_gene_counts which expects "GeneName-Number" format
  gene_result <- generate_gene_counts(transcript_counts_renamed, show_progress = FALSE)
  gene_counts <- gene_result$gene_counts
  # We use our input transcript_info, not the one generated by the function
  
  # Check gene name consistency
  source("check_gene_name_consistency.R")
  consistency_check <- check_gene_name_consistency(gene_counts, transcript_counts_renamed, transcript_info)
  
  # Source required functions in development mode (reload to get latest changes)
  source("/Users/jc952373/Documents/BioMathStiX/My_Packages/ScIsoX/R/qc_utils.R")
  source("/Users/jc952373/Documents/BioMathStiX/My_Packages/ScIsoX/R/create_scht.R")  # This should now have the transcript name fix
  source("/Users/jc952373/Documents/BioMathStiX/My_Packages/ScIsoX/R/complexity_metrics.R")
  
  # Use the QC parameters from the original analysis
  qc_params <- list(
    min_genes_per_cell = 4000,
    max_genes_per_cell = 10000,
    min_cells_expressing = 0.02,
    min_expr = 1e-6
  )
  n_hvg <- 3000
  
  cat("Using QC parameters:\n")
  cat(sprintf("  min_genes_per_cell: %d\n", qc_params$min_genes_per_cell))
  cat(sprintf("  max_genes_per_cell: %d\n", qc_params$max_genes_per_cell))
  cat(sprintf("  min_cells_expressing: %.2f\n", qc_params$min_cells_expressing))
  cat(sprintf("  min_expr: %.0e\n", qc_params$min_expr))
  cat(sprintf("  n_hvg: %d\n", n_hvg))
  
  # Debug HVG mismatch
  source("debug_hvg_mismatch.R")
  debug_info <- debug_hvg_mismatch(gene_counts, transcript_counts_renamed, transcript_info)
  
  # Debug QC filtering
  source("debug_qc_filtering.R")
  qc_info <- debug_qc_filtering(gene_counts, qc_params)
  
  # Test transcript lookup
  source("test_transcript_lookup.R")
  lookup_info <- test_transcript_lookup(transcript_counts_renamed, transcript_info)
  
  # Check HVG selection and multi-isoform status
  source("check_hvg_multi_isoform.R")
  hvg_check <- check_hvg_multi_isoform(gene_counts, transcript_info, qc_params, n_hvg)
  
  # Debug Step 6 lookup if we have multi-isoform HVGs
  if (length(hvg_check$hvgs_multi) > 0) {
    source("debug_step6_lookup.R")
    debug_step6_lookup(hvg_check$hvgs_multi, transcript_counts_renamed, transcript_info)
    
    # More detailed debugging of create_scht Step 6
    source("debug_create_scht_step6.R")
    debug_scht_result <- debug_create_scht_step6(gene_counts, transcript_counts_renamed, 
                                                  transcript_info, metadata, qc_params, n_hvg)
  }
  
  # Calculate original metrics as baseline
  cat("\nCalculating baseline metrics...\n")
  scht_original <- create_scht(
    gene_counts = gene_counts,
    transcript_counts = transcript_counts_renamed,
    transcript_info = transcript_info,
    cell_info = metadata,
    qc_params = qc_params,
    n_hvg = n_hvg
  )
  
  # Simple HVG check on SCHT object
  source("simple_hvg_check.R")
  simple_hvg_check(scht_original)
  
  # Debug SCHT structure
  cat("\n=== Checking SCHT Structure ===\n")
  cat("Names in SCHT object:\n")
  print(names(scht_original))
  
  # The SCHT is stored in original_results
  if (!is.null(scht_original$original_results)) {
    cat("\nNames in original_results:\n")
    print(names(scht_original$original_results))
    
    if (!is.null(scht_original$original_results$SCHT)) {
      cat(sprintf("\nNumber of genes in original_results$SCHT: %d\n", 
                  length(scht_original$original_results$SCHT)))
      
      if (length(scht_original$original_results$SCHT) > 0) {
        cat("\nFirst 5 genes with multiple isoforms:\n")
        print(head(names(scht_original$original_results$SCHT), 5))
      }
    }
  }
  
  # If SCHT is empty, we can't proceed
  if (is.null(scht_original$original_results$SCHT) || 
      length(scht_original$original_results$SCHT) == 0) {
    stop("No genes with multiple isoforms found in SCHT structure.\n",
         "The SCHT creation process filtered out all multi-isoform genes.\n",
         "This could be due to:\n",
         "1. The transcript name mapping issue (now fixed, but needs reload)\n",
         "2. HVGs not having multiple isoforms in this dataset\n",
         "3. QC filtering removing multi-isoform genes")
  }
  
  # If no multi-isoform HVGs, we need to handle this
  if (hvg_info$n_hvgs_multi_iso == 0) {
    stop("No HVGs with multiple isoforms found. Cannot calculate complexity metrics.\n",
         "This could be due to:\n",
         "1. The HVGs selected don't have multiple isoforms\n",
         "2. The transcript matrix doesn't contain multiple isoforms for HVGs\n",
         "Consider using a dataset with more isoform diversity or adjusting parameters.")
  }
  
  original_metrics <- calculate_isoform_complexity_metrics(
    scht_original$original_results,  # Use the actual SCHT structure
    data_driven_thresholds = FALSE,
    visualise = FALSE
  )$metrics
  
  # Check if we got any metrics
  if (nrow(original_metrics) == 0) {
    stop("No genes with multiple isoforms found in the original data. Cannot proceed with robustness testing.")
  }
  
  cat(sprintf("Baseline metrics calculated for %d genes\n", nrow(original_metrics)))
  
  # Initialize results storage
  all_results <- list()
  summary_results <- data.frame()
  
  # Test each dropout level
  for (level in dropout_levels) {
    cat(sprintf("\n--- Testing dropout level: %.0f%% ---\n", level * 100))
    
    level_results <- list()
    
    # Progress bar for iterations
    pb <- progress::progress_bar$new(
      format = "  Iteration [:bar] :percent eta: :eta",
      total = n_iterations,
      clear = FALSE,
      width = 60
    )
    
    successful_iterations <- 0
    
    for (iter in 1:n_iterations) {
      pb$tick()
      
      # Apply dropout (use renamed transcript counts)
      dropout_data <- add_dropout_preserving_structure(
        transcript_counts_renamed, transcript_info,
        dropout_rate = level, 
        seed = iter + level * 1000
      )
      
      # Create SCHT with dropout data
      tryCatch({
        scht_dropout <- create_scht(
          gene_counts = dropout_data$gene_counts,
          transcript_counts = dropout_data$transcript_counts,
          transcript_info = dropout_data$transcript_info,
          cell_info = metadata,
          qc_params = qc_params,
          n_hvg = n_hvg
        )
        
        # Calculate metrics
        metrics_dropout <- calculate_isoform_complexity_metrics(
          scht_dropout$original_results,  # Use the actual SCHT structure
          data_driven_thresholds = FALSE,
          visualise = FALSE
        )$metrics
        
        if (nrow(metrics_dropout) > 0) {
          level_results[[iter]] <- metrics_dropout
          successful_iterations <- successful_iterations + 1
        }
        
      }, error = function(e) {
        # Silently skip failed iterations
      })
    }
    
    cat(sprintf("  Successful iterations: %d/%d\n", successful_iterations, n_iterations))
    
    # Store all iterations for this level
    all_results[[as.character(level)]] <- level_results
    
    # Calculate comparison statistics if we have successful iterations
    if (length(level_results) > 0) {
      # Combine all iterations into one dataframe
      combined_metrics <- do.call(rbind, level_results)
      
      # Load comparison function from current directory
      source("compare_metrics_distributions.R")
      
      comparison <- compare_metrics_distributions(
        list(metrics = original_metrics),
        list(metrics = combined_metrics),
        plot = FALSE,
        save_results = FALSE
      )
      
      # Store summary
      summary_results <- rbind(summary_results, data.frame(
        dropout_level = level,
        n_iterations = successful_iterations,
        mean_cliffs_delta = mean(comparison$cliffs_delta),
        sd_cliffs_delta = sd(comparison$cliffs_delta),
        mean_overlap = mean(comparison$overlap),
        sd_overlap = sd(comparison$overlap),
        min_overlap = min(comparison$overlap),
        max_overlap = max(comparison$overlap)
      ))
      
      cat(sprintf("  Mean overlap coefficient: %.3f ± %.3f\n", 
                  mean(comparison$overlap), sd(comparison$overlap)))
      cat(sprintf("  Mean Cliff's Delta: %.3f ± %.3f\n", 
                  mean(comparison$cliffs_delta), sd(comparison$cliffs_delta)))
    }
  }
  
  # Create visualizations (same as before)
  if (save_plots && nrow(summary_results) > 0) {
    cat("\nCreating visualizations...\n")
    
    # Load ggplot2 functions
    plot_results <- function(summary_results, output_dir) {
      # Plot 1: Overlap coefficient vs dropout level
      p1 <- ggplot2::ggplot(summary_results, ggplot2::aes(x = dropout_level * 100)) +
        ggplot2::geom_line(ggplot2::aes(y = mean_overlap), color = "blue", size = 1.2) +
        ggplot2::geom_point(ggplot2::aes(y = mean_overlap), color = "blue", size = 3) +
        ggplot2::geom_ribbon(ggplot2::aes(ymin = mean_overlap - sd_overlap, 
                                         ymax = mean_overlap + sd_overlap),
                            alpha = 0.2, fill = "blue") +
        ggplot2::geom_hline(yintercept = 0.8, linetype = "dashed", color = "red") +
        ggplot2::scale_y_continuous(limits = c(0, 1)) +
        ggplot2::labs(
          title = "Metric Stability Under Dropout Conditions",
          subtitle = sprintf("Based on %d iterations per dropout level", n_iterations),
          x = "Dropout Rate (%)",
          y = "Mean Overlap Coefficient",
          caption = "Red line indicates high similarity threshold (0.8)"
        ) +
        ggplot2::theme_minimal(base_size = 12) +
        ggplot2::theme(
          plot.title = ggplot2::element_text(face = "bold"),
          panel.grid.minor = ggplot2::element_blank()
        )
      
      ggplot2::ggsave(file.path(output_dir, "dropout_overlap_coefficient.pdf"), 
                     p1, width = 8, height = 6)
    }
    
    plot_results(summary_results, output_dir)
    
    # Save summary table
    write.csv(summary_results, 
              file.path(output_dir, "dropout_summary_statistics.csv"),
              row.names = FALSE)
    
    cat(sprintf("\nResults saved to: %s\n", output_dir))
  }
  
  # Print final summary
  cat("\n=== Summary ===\n")
  if (nrow(summary_results) > 0) {
    cat("Dropout Level | Mean Overlap | Mean Cliff's Delta\n")
    cat("------------------------------------------------\n")
    for (i in 1:nrow(summary_results)) {
      cat(sprintf("    %3.0f%%     |    %.3f    |      %.3f\n",
                  summary_results$dropout_level[i] * 100,
                  summary_results$mean_overlap[i],
                  summary_results$mean_cliffs_delta[i]))
    }
  } else {
    cat("No successful iterations completed.\n")
  }
  
  # Return all results
  return(list(
    original_metrics = original_metrics,
    dropout_results = all_results,
    summary = summary_results,
    qc_params = qc_params
  ))
}

# Example usage
if (interactive()) {
  cat("\nExample usage:\n")
  cat("==============\n")
  cat("# Load your data\n")
  cat("transcript_counts <- readRDS('transcript_counts.rds')\n")
  cat("transcript_info <- readRDS('transcript_info.rds')\n")
  cat("metadata <- readRDS('metadata.rds')\n\n")
  cat("# Run dropout analysis\n")
  cat("results <- run_dropout_robustness_v2(\n")
  cat("  transcript_counts, transcript_info, metadata,\n")
  cat("  dropout_levels = c(0.1, 0.2, 0.3, 0.4, 0.5),\n")
  cat("  n_iterations = 20\n")
  cat(")\n")
}