#!/usr/bin/env Rscript
##################################################################
#  Compare Metrics Distributions between Two Normalizations       #
##################################################################

compare_metrics_distributions <- function(tc_results_1, tc_results_2, 
                                        plot = TRUE, save_results = TRUE,
                                        label1 = "Method 1", label2 = "Method 2") {
  
  cat(sprintf("\n=== Comparing Metrics Distributions (%s vs %s) ===\n\n", label1, label2))
  
  # Extract metrics dataframes
  metrics_1 <- tc_results_1$metrics
  metrics_2 <- tc_results_2$metrics
  
  cat(sprintf("%s results: %d genes\n", label1, nrow(metrics_1)))
  cat(sprintf("%s results: %d genes\n\n", label2, nrow(metrics_2)))
  
  # Define the 7 core metrics to compare
  core_metrics <- c(
    "intra_cellular_isoform_diversity",
    "inter_cellular_isoform_diversity", 
    "intra_cell_type_heterogeneity",
    "inter_cell_type_specificity",
    "intra_cell_type_heterogeneity_variability",
    "inter_cell_type_difference_variability",
    "cell_type_coexpression_variability"
  )
  
  # Helper function for Cliff's Delta
  calculate_cliffs_delta <- function(x, y) {
    nx <- length(x)
    ny <- length(y)
    dominance <- 0
    for (i in 1:nx) {
      for (j in 1:ny) {
        if (x[i] > y[j]) dominance <- dominance + 1
        else if (x[i] < y[j]) dominance <- dominance - 1
      }
    }
    abs(dominance / (nx * ny))
  }
  
  # Helper function for Overlap Coefficient
  calculate_overlap <- function(x, y) {
    dx <- density(x, bw = "SJ")
    dy <- density(y, bw = "SJ")
    range_min <- max(min(dx$x), min(dy$x))
    range_max <- min(max(dx$x), max(dy$x))
    grid <- seq(range_min, range_max, length.out = 1000)
    fx <- approx(dx$x, dx$y, grid)$y
    fy <- approx(dy$x, dy$y, grid)$y
    sum(pmin(fx, fy, na.rm = TRUE)) * (grid[2] - grid[1])
  }
  
  # Initialize results storage
  comparison_results <- data.frame(
    metric = character(),
    cliffs_delta = numeric(),
    overlap = numeric(),
    n_method1 = integer(),
    n_method2 = integer(),
    stringsAsFactors = FALSE
  )
  
  # Calculate statistics for each metric
  cat("Non-parametric Comparison Results:\n")
  cat("==================================\n")
  
  for (metric in core_metrics) {
    # Extract non-NA values for each metric
    values_1 <- metrics_1[[metric]][!is.na(metrics_1[[metric]])]
    values_2 <- metrics_2[[metric]][!is.na(metrics_2[[metric]])]
    
    # Calculate Cliff's Delta
    cliffs_delta <- calculate_cliffs_delta(values_1, values_2)
    
    # Calculate Overlap Coefficient
    overlap <- calculate_overlap(values_1, values_2)
    
    # Store results
    comparison_results <- rbind(comparison_results, data.frame(
      metric = metric,
      cliffs_delta = cliffs_delta,
      overlap = overlap,
      n_method1 = length(values_1),
      n_method2 = length(values_2),
      stringsAsFactors = FALSE
    ))
    
    # Print results
    cat(sprintf("%-45s: Cliff's Delta = %.3f, Overlap = %.3f\n", 
                gsub("_", " ", metric),
                cliffs_delta,
                overlap))
  }
  
  cat("\nInterpretation Guidelines:\n")
  cat("- Cliff's Delta: <0.147 (negligible), 0.147-0.33 (small), 0.33-0.474 (medium), >0.474 (large)\n")
  cat("- Overlap: >0.8 (high similarity), 0.5-0.8 (moderate), <0.5 (low similarity)\n")
  
  # Summary
  cat("\nSummary:\n")
  cat(sprintf("- Metrics with negligible differences (Cliff's Delta < 0.147): %d/7\n", 
              sum(comparison_results$cliffs_delta < 0.147)))
  cat(sprintf("- Metrics with high overlap (> 0.8): %d/7\n", 
              sum(comparison_results$overlap > 0.8)))
  cat(sprintf("- Mean Cliff's Delta: %.3f\n", mean(comparison_results$cliffs_delta)))
  cat(sprintf("- Mean overlap coefficient: %.3f\n", mean(comparison_results$overlap)))
  
  # Create comparison plots if requested
  if (plot) {
    library(ggplot2)
    library(gridExtra)
    
    cat("\nCreating comparison plots...\n")
    
    plots <- list()
    
    for (i in 1:length(core_metrics)) {
      metric <- core_metrics[i]
      
      # Combine data for plotting
      plot_data <- rbind(
        data.frame(
          value = metrics_1[[metric]],
          method = label1,
          stringsAsFactors = FALSE
        ),
        data.frame(
          value = metrics_2[[metric]],
          method = label2,
          stringsAsFactors = FALSE
        )
      )
      
      # Remove NAs
      plot_data <- plot_data[!is.na(plot_data$value), ]
      
      # Create density plot
      p <- ggplot(plot_data, aes(x = value, fill = method)) +
        geom_density(alpha = 0.5) +
        labs(
          title = tools::toTitleCase(gsub("_", " ", metric)),
          subtitle = sprintf("Cliff's Delta = %.3f, Overlap Coefficient = %.3f", 
                           comparison_results$cliffs_delta[i],
                           comparison_results$overlap[i]),
          x = "Metric Value",
          y = "Density"
        ) +
        theme_minimal() +
        scale_fill_manual(values = setNames(c("blue", "red"), c(label1, label2))) +
        theme(
          plot.title = element_text(size = 10),
          plot.subtitle = element_text(size = 8),
          legend.position = c(0.8, 0.8)
        )
      
      plots[[i]] <- p
    }
    
    # Arrange plots in a grid
    combined_plot <- do.call(gridExtra::grid.arrange, c(plots, ncol = 3, nrow = 3))
    
    if (save_results) {
      ggsave("metrics_distribution_comparison.pdf", 
             combined_plot, 
             width = 12, 
             height = 10)
      cat("Plots saved to: metrics_distribution_comparison.pdf\n")
    }
  }
  
  # Save detailed results if requested
  if (save_results) {
    write.csv(comparison_results, "distribution_comparison_results.csv", row.names = FALSE)
    cat("\nDetailed results saved to: distribution_comparison_results.csv\n")
  }
  
  # Return both summary statistics and raw values for each metric
  return(invisible(list(
    summary = comparison_results,
    cliffs_delta = setNames(comparison_results$cliffs_delta, comparison_results$metric),
    overlap = setNames(comparison_results$overlap, comparison_results$metric)
  )))
}

# Example usage
if (interactive()) {
  cat("\nExample usage:\n")
  cat("==============\n")
  cat("# Load your two complexity results\n")
  cat("tc_results_1 <- readRDS('complexity_results_1.rds')\n")
  cat("tc_results_2 <- readRDS('complexity_results_2.rds')\n\n")
  cat("# Compare distributions\n")
  cat("results <- compare_metrics_distributions(tc_results_1, tc_results_2,\n")
  cat("                                          label1 = 'Original', label2 = 'Dropout 10%')\n")
}