#!/usr/bin/env Rscript
##################################################################
#  Dropout Robustness Test for ScIsoX Complexity Metrics        #
##################################################################


#' Add dropout to a sparse matrix
#' 
#' @param matrix Sparse matrix (dgCMatrix)
#' @param dropout_rate Proportion of non-zero values to convert to zero
#' @param seed Random seed for reproducibility
#' @return Matrix with added dropout
add_dropout <- function(matrix, dropout_rate, seed = NULL) {
  if (!is.null(seed)) set.seed(seed)
  
  # Find all non-zero entries
  non_zero_idx <- which(matrix > 0, arr.ind = TRUE)
  n_non_zero <- nrow(non_zero_idx)
  
  # Calculate how many to drop
  n_dropout <- round(n_non_zero * dropout_rate)
  
  if (n_dropout == 0) return(matrix)
  
  # Randomly select entries to drop
  dropout_idx <- sample(1:n_non_zero, n_dropout, replace = FALSE)
  
  # Create a copy of the matrix
  matrix_dropout <- matrix
  
  # Set selected entries to zero
  for (i in dropout_idx) {
    matrix_dropout[non_zero_idx[i, 1], non_zero_idx[i, 2]] <- 0
  }
  
  # Ensure it remains sparse
  matrix_dropout <- drop0(matrix_dropout)
  
  return(matrix_dropout)
}

#' Run dropout robustness analysis
#' 
#' @param transcript_counts Original transcript count matrix
#' @param metadata Cell metadata
#' @param dropout_levels Vector of dropout rates to test
#' @param n_iterations Number of iterations per dropout level
#' @param output_dir Directory to save results
#' @param save_plots Whether to save plots
#' @return List containing all results
run_dropout_robustness <- function(transcript_counts, 
                                 metadata,
                                 dropout_levels = c(0.1, 0.2, 0.3, 0.4, 0.5),
                                 n_iterations = 20,
                                 output_dir = "results/dropout_robustness",
                                 save_plots = TRUE) {
  
  cat("\n=== Dropout Robustness Analysis ===\n")
  cat(sprintf("Testing %d dropout levels with %d iterations each\n", 
              length(dropout_levels), n_iterations))
  
  # Create output directory
  if (save_plots && !dir.exists(output_dir)) {
    dir.create(output_dir, recursive = TRUE)
  }
  
  # Generate gene counts and transcript info from original data
  cat("\nGenerating baseline gene counts...\n")
  original_gene_result <- generate_gene_counts(transcript_counts, show_progress = FALSE)
  gene_counts <- as(as.matrix(original_gene_result$gene_counts), "sparseMatrix")
  transcript_info <- original_gene_result$transcript_info
  
  # Get QC parameters from original data
  qc_rec <- recommend_qc_parameters(gene_counts)
  qc_params <- list(
    min_genes_per_cell = qc_rec$Interval_90$min_genes_per_cell,
    max_genes_per_cell = qc_rec$Interval_90$max_genes_per_cell,
    min_cells_expressing = 0.02,
    min_expr = 1e-4
  )
  
  # Calculate original metrics as baseline
  cat("Calculating baseline metrics...\n")
  scht_original <- create_scht(
    gene_counts = gene_counts,
    transcript_counts = transcript_counts,
    transcript_info = transcript_info,
    cell_info = metadata,
    qc_params = qc_params
  )
  
  original_metrics <- calculate_isoform_complexity_metrics(
    scht_original, 
    data_driven_thresholds = FALSE,
    visualise = FALSE
  )$metrics
  
  # Initialize results storage
  all_results <- list()
  summary_results <- data.frame()
  
  # Test each dropout level
  for (level in dropout_levels) {
    cat(sprintf("\n--- Testing dropout level: %.0f%% ---\n", level * 100))
    
    level_results <- list()
    
    # Progress bar for iterations
    pb <- progress::progress_bar$new(
      format = "  Iteration [:bar] :percent eta: :eta",
      total = n_iterations,
      clear = FALSE,
      width = 60
    )
    
    for (iter in 1:n_iterations) {
      pb$tick()
      
      # Add dropout to transcript counts
      transcript_dropout <- add_dropout(
        transcript_counts, 
        dropout_rate = level, 
        seed = iter + level * 1000
      )
      
      # Generate corresponding gene counts
      gene_result <- generate_gene_counts(transcript_dropout, show_progress = FALSE)
      gene_dropout <- as(as.matrix(gene_result$gene_counts), "sparseMatrix")
      
      # Create SCHT with dropout data
      tryCatch({
        scht_dropout <- create_scht(
          gene_counts = gene_dropout,
          transcript_counts = transcript_dropout,
          transcript_info = transcript_info,
          cell_info = metadata,
          qc_params = qc_params
        )
        
        # Calculate metrics
        metrics_dropout <- calculate_isoform_complexity_metrics(
          scht_dropout,
          data_driven_thresholds = FALSE,
          visualise = FALSE
        )$metrics
        
        # Store results
        level_results[[iter]] <- metrics_dropout
        
      }, error = function(e) {
        cat(sprintf("\n  Warning: Iteration %d failed at %.0f%% dropout: %s\n", 
                    iter, level * 100, e$message))
      })
    }
    
    # Store all iterations for this level
    all_results[[as.character(level)]] <- level_results
    
    # Calculate comparison statistics if we have successful iterations
    if (length(level_results) > 0) {
      # Combine all iterations into one dataframe
      combined_metrics <- do.call(rbind, level_results)
      
      # Compare with original using our robust comparison function
      source(file.path(system.file("scripts", package = "ScIsoX"), 
                      "compare_metrics_distributions.R"))
      
      comparison <- compare_metrics_distributions(
        list(metrics = original_metrics),
        list(metrics = combined_metrics),
        plot = FALSE,
        save_results = FALSE
      )
      
      # Store summary
      summary_results <- rbind(summary_results, data.frame(
        dropout_level = level,
        n_iterations = length(level_results),
        mean_cliffs_delta = mean(comparison$cliffs_delta),
        sd_cliffs_delta = sd(comparison$cliffs_delta),
        mean_overlap = mean(comparison$overlap),
        sd_overlap = sd(comparison$overlap),
        min_overlap = min(comparison$overlap),
        max_overlap = max(comparison$overlap)
      ))
      
      cat(sprintf("  Mean overlap coefficient: %.3f ± %.3f\n", 
                  mean(comparison$overlap), sd(comparison$overlap)))
      cat(sprintf("  Mean Cliff's Delta: %.3f ± %.3f\n", 
                  mean(comparison$cliffs_delta), sd(comparison$cliffs_delta)))
    }
  }
  
  # Create visualizations
  if (save_plots && nrow(summary_results) > 0) {
    cat("\nCreating visualizations...\n")
    
    # Plot 1: Overlap coefficient vs dropout level
    p1 <- ggplot(summary_results, aes(x = dropout_level * 100)) +
      geom_line(aes(y = mean_overlap), color = "blue", size = 1.2) +
      geom_point(aes(y = mean_overlap), color = "blue", size = 3) +
      geom_ribbon(aes(ymin = mean_overlap - sd_overlap, 
                      ymax = mean_overlap + sd_overlap),
                  alpha = 0.2, fill = "blue") +
      geom_hline(yintercept = 0.8, linetype = "dashed", color = "red") +
      scale_y_continuous(limits = c(0, 1)) +
      labs(
        title = "Metric Stability Under Dropout Conditions",
        subtitle = sprintf("Based on %d iterations per dropout level", n_iterations),
        x = "Dropout Rate (%)",
        y = "Mean Overlap Coefficient",
        caption = "Red line indicates high similarity threshold (0.8)"
      ) +
      theme_minimal(base_size = 12) +
      theme(
        plot.title = element_text(face = "bold"),
        panel.grid.minor = element_blank()
      )
    
    # Plot 2: Cliff's Delta vs dropout level
    p2 <- ggplot(summary_results, aes(x = dropout_level * 100)) +
      geom_line(aes(y = mean_cliffs_delta), color = "darkgreen", size = 1.2) +
      geom_point(aes(y = mean_cliffs_delta), color = "darkgreen", size = 3) +
      geom_ribbon(aes(ymin = mean_cliffs_delta - sd_cliffs_delta, 
                      ymax = mean_cliffs_delta + sd_cliffs_delta),
                  alpha = 0.2, fill = "darkgreen") +
      geom_hline(yintercept = 0.147, linetype = "dashed", color = "red") +
      geom_hline(yintercept = 0.33, linetype = "dashed", color = "orange") +
      scale_y_continuous(limits = c(0, 0.5)) +
      labs(
        title = "Effect Size Under Dropout Conditions",
        subtitle = "Cliff's Delta: negligible (<0.147), small (0.147-0.33)",
        x = "Dropout Rate (%)",
        y = "Mean Cliff's Delta",
        caption = "Red: negligible threshold, Orange: small threshold"
      ) +
      theme_minimal(base_size = 12) +
      theme(
        plot.title = element_text(face = "bold"),
        panel.grid.minor = element_blank()
      )
    
    # Save plots
    ggsave(file.path(output_dir, "dropout_overlap_coefficient.pdf"), 
           p1, width = 8, height = 6)
    ggsave(file.path(output_dir, "dropout_cliffs_delta.pdf"), 
           p2, width = 8, height = 6)
    
    # Combined plot
    library(gridExtra)
    combined <- grid.arrange(p1, p2, ncol = 1)
    ggsave(file.path(output_dir, "dropout_robustness_combined.pdf"), 
           combined, width = 8, height = 10)
    
    # Save summary table
    write.csv(summary_results, 
              file.path(output_dir, "dropout_summary_statistics.csv"),
              row.names = FALSE)
    
    cat(sprintf("\nResults saved to: %s\n", output_dir))
  }
  
  # Print final summary
  cat("\n=== Summary ===\n")
  cat("Dropout Level | Mean Overlap | Mean Cliff's Delta\n")
  cat("------------------------------------------------\n")
  for (i in 1:nrow(summary_results)) {
    cat(sprintf("    %3.0f%%     |    %.3f    |      %.3f\n",
                summary_results$dropout_level[i] * 100,
                summary_results$mean_overlap[i],
                summary_results$mean_cliffs_delta[i]))
  }
  
  # Return all results
  return(list(
    original_metrics = original_metrics,
    dropout_results = all_results,
    summary = summary_results,
    qc_params = qc_params
  ))
}

# Function to create detailed report
create_dropout_report <- function(results, output_file = "dropout_robustness_report.txt") {
  sink(output_file)
  
  cat("Dropout Robustness Analysis Report\n")
  cat("==================================\n\n")
  cat("Date:", Sys.Date(), "\n")
  cat("ScIsoX Version:", packageVersion("ScIsoX"), "\n\n")
  
  cat("Analysis Parameters:\n")
  cat("-------------------\n")
  cat("Dropout levels tested:", paste(unique(results$summary$dropout_level) * 100, "%"), "\n")
  cat("Iterations per level:", results$summary$n_iterations[1], "\n\n")
  
  cat("Key Findings:\n")
  cat("-------------\n")
  
  # Check if metrics remain stable
  stable_overlap <- all(results$summary$mean_overlap > 0.8)
  stable_effect <- all(results$summary$mean_cliffs_delta < 0.33)
  
  if (stable_overlap && stable_effect) {
    cat("✓ All metrics demonstrated high stability across all dropout levels\n")
    cat("✓ Mean overlap coefficients remained above 0.8 (high similarity)\n")
    cat("✓ Effect sizes remained below 0.33 (negligible to small)\n\n")
  } else {
    cat("⚠ Some metrics showed reduced stability at higher dropout levels\n\n")
  }
  
  cat("Detailed Results:\n")
  cat("-----------------\n")
  print(results$summary)
  
  cat("\n\nConclusion:\n")
  cat("-----------\n")
  cat("The ScIsoX complexity metrics demonstrate ")
  if (stable_overlap && stable_effect) {
    cat("robust performance even under extreme dropout conditions,\n")
    cat("supporting their reliability for sparse single-cell isoform data.\n")
  } else {
    cat("reasonable stability under moderate dropout conditions,\n")
    cat("with some degradation at extreme sparsity levels.\n")
  }
  
  sink()
  cat(sprintf("\nReport saved to: %s\n", output_file))
}

# Example usage
if (interactive()) {
  cat("\nExample usage:\n")
  cat("==============\n")
  cat("# Load your data\n")
  cat("transcript_counts <- readRDS('transcript_counts.rds')\n")
  cat("metadata <- readRDS('metadata.rds')\n\n")
  cat("# Run dropout analysis\n")
  cat("results <- run_dropout_robustness(\n")
  cat("  transcript_counts, metadata,\n")
  cat("  dropout_levels = c(0.1, 0.2, 0.3, 0.4, 0.5),\n")
  cat("  n_iterations = 20\n")
  cat(")\n\n")
  cat("# Create report\n")
  cat("create_dropout_report(results)\n")
}