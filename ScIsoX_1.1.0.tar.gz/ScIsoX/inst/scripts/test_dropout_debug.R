#!/usr/bin/env Rscript

# Debug dropout test with more output
test_dropout_debug <- function() {
  devtools::load_all()
  
  # Load data
  transcript_counts <- readRDS("/Users/jc952373/Documents/BioMathStiX/My_Packages/ScIsoX/inst/extdata/mouse_isoform_df.rds")
  metadata <- readRDS("/Users/jc952373/Documents/BioMathStiX/My_Packages/ScIsoX/inst/extdata/metadata.rds")
  
  # Generate transcript info
  source("/Users/jc952373/Documents/BioMathStiX/My_Packages/ScIsoX/R/generate_gene_counts.R")
  gene_result <- generate_gene_counts(transcript_counts)
  transcript_info <- gene_result$transcript_info
  
  # Load the clean dropout test with modifications
  source("/Users/jc952373/Documents/BioMathStiX/My_Packages/ScIsoX/inst/scripts/dropout_robustness_test_clean.R")
  
  # Test just the dropout and SCHT creation for one iteration
  cat("\n=== Testing single dropout iteration ===\n")
  
  # Apply dropout once
  cat("1. Applying dropout...\n")
  start_time <- Sys.time()
  
  dropout_data <- add_dropout_preserving_structure(
    transcript_counts, 
    transcript_info,
    dropout_rate = 0.1, 
    seed = 123
  )
  
  cat("   Dropout completed in", difftime(Sys.time(), start_time, units = "secs"), "seconds\n")
  cat("   Original non-zeros:", sum(transcript_counts > 0), "\n")
  cat("   After dropout non-zeros:", sum(dropout_data$transcript_counts > 0), "\n")
  
  # Create SCHT with dropout data
  cat("\n2. Creating SCHT with dropout data...\n")
  start_time <- Sys.time()
  
  scht_dropout <- create_scht(
    gene_counts = dropout_data$gene_counts,
    transcript_counts = dropout_data$transcript_counts,
    transcript_info = dropout_data$transcript_info,
    cell_info = metadata,
    qc_params = list(
      min_genes_per_cell = 200,
      max_genes_per_cell = 10000,
      min_cells_expressing = 0.02,
      min_expr = 1e-6
    ),
    n_hvg = 3000
  )
  
  cat("   SCHT creation completed in", difftime(Sys.time(), start_time, units = "secs"), "seconds\n")
  cat("   Found", length(scht_dropout$original_results), "genes in SCHT\n")
  
  # Calculate metrics
  cat("\n3. Calculating metrics for dropout data...\n")
  start_time <- Sys.time()
  
  metrics_dropout <- calculate_isoform_complexity_metrics(
    scht_dropout,
    data_driven_thresholds = FALSE,
    visualise = FALSE
  )$metrics
  
  cat("   Metric calculation completed in", difftime(Sys.time(), start_time, units = "secs"), "seconds\n")
  cat("   Calculated metrics for", nrow(metrics_dropout), "genes\n")
  
  return(list(
    dropout_data = dropout_data,
    scht_dropout = scht_dropout,
    metrics_dropout = metrics_dropout
  ))
}

# Run the debug test
result <- test_dropout_debug()