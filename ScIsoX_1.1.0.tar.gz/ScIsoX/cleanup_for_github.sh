#!/bin/bash
##################################################################
#  Cleanup Script for ScIsoX Package before GitHub Push          #
##################################################################

echo "Starting cleanup for ScIsoX package..."

# Create backup first
echo "Creating backup..."
BACKUP_DIR="../ScIsoX_backup_$(date +%Y%m%d_%H%M%S)"
cp -r . "$BACKUP_DIR"
echo "Backup created at: $BACKUP_DIR"

# Remove QC report outputs
echo "Removing QC report outputs..."
rm -rf my_qc_report/

# Remove test results from inst/scripts
echo "Removing test results and outputs..."
rm -f inst/scripts/distribution_comparison_results.csv
rm -f inst/scripts/metrics_distribution_comparison.pdf
rm -rf inst/scripts/results/

# Remove empty directories
echo "Removing empty directories..."
rmdir blood_robustness_results/ 2>/dev/null
rmdir robustness_results/ 2>/dev/null

# Remove any temporary files
echo "Removing temporary files..."
find . -name "*.log" -delete
find . -name "*.out" -delete
find . -name "*.err" -delete
find . -name "*~" -delete
find . -name ".DS_Store" -delete

# Count remaining files
echo ""
echo "Cleanup complete!"
echo "Remaining structure:"
echo "- R files: $(find R -name "*.R" | wc -l)"
echo "- Man files: $(find man -name "*.Rd" | wc -l)"
echo "- Scripts: $(find inst/scripts -name "*.R" | wc -l)"

echo ""
echo "Don't forget to:"
echo "1. Review the .gitignore file"
echo "2. Check for any sensitive information in the code"
echo "3. Run 'devtools::check()' before pushing"
echo "4. Update version number in DESCRIPTION if needed"