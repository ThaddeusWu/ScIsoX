#!/bin/bash
# Update all R file dates to Jul 29, 2025

cd /Users/jc952373/Documents/BioMathStiX/My_Packages/ScIsoX/R

# Update dates in all R files
for file in *.R; do
    echo "Updating date in $file"
    # Use sed to replace any date pattern with Jul 29, 2025
    sed -i '' 's/#  Date: Jul [0-9][0-9], 2025/#  Date: Jul 29, 2025/g' "$file"
done

echo "Date updates complete!"